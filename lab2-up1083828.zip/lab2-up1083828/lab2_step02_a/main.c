#include <stdio.h>
#define N 10

int load(double x[N]) ;
int print(double x[N]) ;
double computesum(double x[N]);
int printsum(double sum);

int main() {
    int i;
    double data[N];
    double sum;

    load(data);
    print(data);

    sum = computesum(data);
    printsum(sum);
    printf("\n%g\n", sum);

    return 0;
}

int print(double x[N]) {
    int i;
    for (i=0; i<N; i++) {
        printf(" %g ", x[i]) ;
    }
    return 0;
}
int load(double x[N]) {
    int i;
    for (i=0; i<N; i++) {
        x[i] = ((double) i) / N ;
    }
    return 0;
}

double computesum(double x[N]) {
    int i;
    double sum = 0.0;
    for(i = 0; i < N; i++){
        sum = sum + x[i];
    }
    return sum;
}

int printsum(double sum) {
    printf("\n%g\n", sum);
    return 0;
}
