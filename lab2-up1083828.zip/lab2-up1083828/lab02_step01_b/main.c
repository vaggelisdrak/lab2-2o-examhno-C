#include <stdio.h>
#define N 10
#define M 10


int main() {
    int i,j;
    double data[N][M];
    double sum = 0.0;

    for(i = 0; i < N; i++) {
        for(j = 0; j < M; j++){
            data[i][j] = ((double) i+j) / N ;
        }
    }
    for(i = 0; i < N; i++) {
        for(j = 0; j < M; j++){
            printf(" %g ", data[i][j]);
        }
        printf("\n");
    }

    for(i = 0; i < N; i++) {
        for(j = 0; j < M; j++){
            sum = sum + data[i][j];
        }
    }

    printf("\n%g\n", sum);
    return 0;
}
